const fs=require('fs'),path=require('path');
const res='android/app/src/main/res';
if(fs.existsSync(res)){
  ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'].forEach(d=>{
    const src=path.join('icons','mipmap-'+d),dst=path.join(res,'mipmap-'+d);
    if(!fs.existsSync(src))return;
    fs.mkdirSync(dst,{recursive:true});
    fs.readdirSync(src).forEach(f=>fs.copyFileSync(path.join(src,f),path.join(dst,f)));
  });
  fs.mkdirSync(path.join(res,'values'),{recursive:true});
  fs.writeFileSync(path.join(res,'values','ic_launcher_background.xml'),'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFD9A0</color>\n</resources>\n');
  const any=path.join(res,'mipmap-anydpi-v26');
  fs.mkdirSync(any,{recursive:true});
  const xml='<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  ['ic_launcher.xml','ic_launcher_round.xml'].forEach(n=>fs.writeFileSync(path.join(any,n),xml));
  console.log('cat icons installed');
}
